#pragma once
#include <list>
#include "STDIO_FW\Video\Image.h"
#include "EntityManager.h"
using namespace stdio_fw;
#define TurtleImage "Net2.png"
#define ImgList ImageList()

std::vector <Image*> ImageList();