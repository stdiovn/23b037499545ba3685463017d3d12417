#include "stdafx.h"
#include "MovementSystem.h"
#define _USE_MATH_DEFINES
#include <math.h>
#include "Support.h"
MovementSystem::MovementSystem()
{
}

MovementSystem::~MovementSystem()
{
}

void MovementSystem::Update()
{
	std::list<Entity*> entities = EntityManager::GetInstance()->GetEntityList();
	std::list<Entity*>::iterator CurrEntity = entities.begin();

	while (CurrEntity != entities.end())
	{

		Entity* E = *CurrEntity;
		if (E->hasMovementComponent())
		{
			MoveComp& comp = E->GetMoveComp();
			if (comp.m_Type == 1)
			{
				E->SetX(E->GetX() + comp.m_Velocity);
				E->SetY(60 * sin(E->GetX() * M_PI / 180));
			}
			else if (comp.m_Type == 2)
			{
				E->SetX(E->GetX() + comp.m_Velocity);
			}
			else
			{
				exit(1);
			}
		}
		CurrEntity++;
	}
	
}
void MovementSystem::Render(Graphics* g)
{
}

